const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();

exports.handler = (event,context,callback) => {
    // TODO implement
    console.log(event.Records[0].Sns.Message);
    const Message = JSON.parse(event.Records[0].Sns.Message)
    var params = {
        TableName:'BlockEmails',
        Item: {
            emailId: Message.complaint.complainedRecipients[0].emailAddress,
            noOfAttempts: 1,
            type: Message.complaint.complaintFeedbackType,
        }
    }
    console.log(params);
    docClient.put(params,function(err,data){
        if(err){
            console.log(err);
            //alert here
        }
        else {
            console.log(data);
        }
    })
};
