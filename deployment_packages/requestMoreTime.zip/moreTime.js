const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();

function forwardUsers(appointmentData,context,callback) {
    let transactWrite = [],lastSK,lastAppointmentTime;
    const {
        storeId,
        SK,
        requestTime,
        EstimatedAppointmentTime,
        AppointmentID,
        Timestamp,
        UserID,
    } = appointmentData;
    var params = {
        TableName: "Crowdless",
        KeyConditionExpression: "PK = :pk and SK > :current",
        FilterExpression: "EstimatedAppointmentTime <= :requestedTime",
        ExpressionAttributeValues: {
            ":pk": storeId,
            ":current": SK.substr(0,9) + (Number(SK.substr(9))+1),
            ":requestTime": EstimatedAppointmentTime+requestTime,
        }
    };
    docClient.query(params, function(err,data) {
        if(err) {
            callback(null,{
                statusCode: 500,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                },
                body: JSON.stringify({
                    Message: "Failed to get Appointment Details",
                    error: err
                }),
            });
            context.done(null,err);
            return;
        }
        console.log(data);
        const onestep = data.Items[0].EstimatedAppointmentTime - EstimatedAppointmentTime;
        data.Items.map((appointment) => {
            transactWrite.push({
                Update: {
                    TableName: 'Crowdless',
                    Key: {
                        "PK": appointment.PK,
                        "SK": appointment.SK
                    },
                    UpdateExpression: "set EstimatedAppointmentTime = EstimatedAppointmentTime - :onestep",
                    ExpressionAttributeValues: {
                        ":onestep" : onestep
                    }
                }
            });
            lastSK = appointment.SK;
            lastAppointmentTime = appointment.EstimatedAppointmentTime;
        });
        /* Try to check if immediate next result exists or not, because otherwise
            decimal priority number might cause trouble */
        if(lastAppointmentTime+onestep <= EstimatedAppointmentTime+requestTime) {  //Issue: Fractional priority number might result in mimsbehaving of other features, Please check
            transactWrite.push({
                Put: {
                    TableName: 'Crowdless',
                    Items: {
                        "PK": storeId,
                        "SK": lastSK.substr(0,9) + (Number(lastSK.substr(9)) + Math.ceil(Number(lastSK.substr(9))+0.000000000001))/2.0,
                        "EstimatedAppointmentTime": EstimatedAppointmentTime+requestTime,
                        AppointmentID,
                        UserID,
                        Status: "Waiting",
                        Timestamp
                    }
                }
            });
        }
        else {
            transactWrite.push({
                Put: {
                    TableName: 'Crowdless',
                    Items: {
                        "PK": storeId,
                        "SK": lastSK.substr(0,9) + (Number(lastSK.substr(9)) + Math.ceil(Number(lastSK.substr(9))+0.000000000001))/2.0,
                        "EstimatedAppointmentTime": EstimatedAppointmentTime+requestTime,
                        AppointmentID,
                        UserID,
                        Status: "Waiting",
                        Timestamp
                    }
                }
            });
        }
    });
}