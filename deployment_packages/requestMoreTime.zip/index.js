const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();
const moreTime = require('./moreTime');

exports.handler = (event,context,callback) => {
    console.log(event);
    // const body = JSON.parse(event.body)
    const body = event;
    const storeId = body.storeId;
    const SK = body.SK;
    const requestTime = body.requestTime;
    const currentTime = Math.ceil((new Date().getTime())/1000);
    var params = {
        TableName: 'Crowdless',
        Key: {
            "PK": storeId,
            "SK": SK
        }
    }
    docClient.get(params, function(err,data) {
        if(err) {
            callback(null,{
                statusCode: 500,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                },
                body: JSON.stringify({
                    Message: "Failed to get Appointment Details",
                    error: err
                }),
            });
            context.done(null,err);
            return;
        }
        console.log(data);
        var appointmentData = {
            storeId,
            SK,
            requestTime,
            EstimatedAppointmentTime: data.Item.EstimatedAppointmentTime
        };
        if(data.Item.EstimatedAppointmentTime - currentTime > 300) {
            // Forward 1 step to all users until Request increase time. and insert user there
        }
        else {
            //Backpush all users after Request increase time and insert user there
        }
    });
    
};
