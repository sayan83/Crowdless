const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();
const lambda = new AWS.Lambda();
const s3 = new AWS.S3();
const uuid = require('uuid');
const qrcode = require('qrcode');

exports.handler = (event,context,callback) => {
    let transactWrite = []
    console.log('event here ...',event);
    const date = new Date();
    const currentHrs = `${date.getHours()}${date.getMinutes()<10?date.getMinutes()*10:date.getMinutes()}`;
    // + date.getMinutes()<10?`${date.getMinutes()}0`:`${date.getMinutes()}`;
    console.log(date.getHours(),date.getMinutes())
    console.log(date)
    console.log(currentHrs)
    const year = `${date.getFullYear()}`;
    const month = (date.getMonth() <= 8)?`0${date.getMonth()+1}`:`${date.getMonth()+1}`;
    const day = (date.getDate() <= 9)?`0${date.getDate()}`:`${date.getDate()}`;
    const SKPrefix = `${year}${month}${day}`
    // const email = event.requestContext.authorizer.claims.email;
    // console.log(email);
    const {storeId,name,email,phoneNo} = JSON.parse(event.body)
    // const storeId = 'S001';
    // const userId = 'U005';
    // const email = 'sayanbis83@gmail.com';
    //TODO : get details of store( avg_wait_time & last priority no. )
    var params = {
        TableName: 'Crowdless',
        KeyConditionExpression: "PK = :pk and SK between :date and :info",
        ExpressionAttributeValues: {
            ":pk": storeId,         // Add storeId here
            ":date": SKPrefix,    // Add current date here YYYYMMDD
            ":info": "STORE_INFO"
        },
        ScanIndexForward: false,
        Limit: 4
    };
    docClient.query(params, function(err,data) {
        if(err){
            callback(null,{
                statusCode: 500,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                },
                body: JSON.stringify({
                    Message: "Failed to get store Details",
                    error: err
                }),
            });
            context.done(null,err);
            return;
        }
        console.log(data);
        var {bookingEndTime, bookingStartTime,timezone,storeAddress,storeLogo} = data.Items[0];
        const storeName = data.Items[0].Name;
        const avg_wait_time = data.Items[0].Avg_Wait_Time;
        var last_active_priority_no = data.Items[1].Priority;
        let priority,lastAppointmentTime=0;
        if(data.Items[3]) {
            priority = data.Items[3].SK.substr(data.Items[3].SK.indexOf('#')+1);
            lastAppointmentTime = data.Items[3].EstimatedAppointmentTime;
        }
        else {
            priority = -1;
            if(last_active_priority_no !== -1) {
                last_active_priority_no = -1;
                transactWrite.push({
                    Update: {
                        TableName: "Crowdless",
                        Key: {
                            PK: storeId,
                            SK: "LAST_ACTIVE_PRIORITY_NO"
                        },
                        UpdateExpression: 'set Priority = :val',
                        ExpressionAttributeValues: {
                            ":val": -1
                        }
                    }
                });
            }
            if(data.Items[2].Value !== 0 || data.Items[2].Customer_Delay_Time !== 0) {
                transactWrite.push({
                    Update: {
                        TableName: "Crowdless",
                        Key: {
                            PK: storeId,
                            SK: "DELAY_COUNT"
                        },
                        UpdateExpression: 'set #val = :val, Customer_Delay_Time = :val',
                        ExpressionAttributeNames: {
                            "#val": "Value"
                        },
                        ExpressionAttributeValues: {
                            ":val": 0,
                        }
                    }
                });
            }
        }
        console.log(avg_wait_time,last_active_priority_no,priority);
        AppointmentTime(email,currentHrs,bookingStartTime,bookingEndTime,timezone,lastAppointmentTime,transactWrite,storeName,storeAddress,storeLogo,avg_wait_time,last_active_priority_no,priority,storeId,name,email,phoneNo,SKPrefix,context,callback);
    });
    
    //TODO : calcuate approx appointment time ( done check AppointmentTime() below)
    
    //TODO : Generate QR code 
    
    //TODO : Create a new appointment details and add it to DB (done check addAppointmentRecord)
    
    //TODO : Send notification SMS & email
    
    //TODO : Return response to user 
};

function AppointmentTime(email,currentHrs,bookingStartTime,bookingEndTime,timezone,lastAppointmentTime,transactWrite,storeName,storeAddress,storeLogo,avg_wait_time,last_active_priority_no,priority,storeId,name,email,phoneNo,SKPrefix,context,callback) {
    //Get Offline details to calculate offline_consideration_factor
    const offline_consideration_factor = 2;
        const date = new Date()
        const timestamp = Math.ceil(date.getTime()/1000);
        const priority_diff = priority - last_active_priority_no;
        let expected_appointment_time;
        if(lastAppointmentTime > timestamp) {
            expected_appointment_time = lastAppointmentTime + (offline_consideration_factor + 1)*avg_wait_time;
        }
        else {
            //if timestamp < appointmentTime then
            if(currentHrs < bookingStartTime) {
                var dateToParse = date.toString();
                bookingStartTime = bookingStartTime.toString()
                var startTime = `${bookingStartTime[0]}${bookingStartTime[1]}:${bookingStartTime[2]}${bookingStartTime[3]}:00`;
                dateToParse = dateToParse.replace(dateToParse.substr(16,8),startTime);
                var newTimestamp = Date.parse(dateToParse)/1000; 
                expected_appointment_time = newTimestamp + (offline_consideration_factor + 1)*avg_wait_time;
            }
            else {
                expected_appointment_time = timestamp + (offline_consideration_factor + 1)*avg_wait_time;
            }
        }
        var dateToParse = date.toString();
        bookingEndTime = bookingEndTime.toString()
        var endTime = `${bookingEndTime[0]}${bookingEndTime[1]}:${bookingEndTime[2]}${bookingEndTime[3]}:00`;
        dateToParse = dateToParse.replace(dateToParse.substr(16,8),endTime);
        console.log(endTime,dateToParse)
        var endTimestamp = Date.parse(dateToParse)/1000;
        console.log(expected_appointment_time,endTimestamp,newTimestamp)
        console.log(currentHrs,expected_appointment_time,endTimestamp,newTimestamp);
        if(expected_appointment_time > endTimestamp){
            callback(null,{
                statusCode: 200,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                },
                body: JSON.stringify({
                    message: 'Appointment Full for today',
                }),
            });
            return;
        }
    // const expected_appointment_time =timestamp + (priority_diff + 1)*avg_wait_time + priority_diff*offline_consideration_factor*avg_wait_time;
    console.log(timestamp,expected_appointment_time);
    //If estimatedAppointmentTime > appointmentEndTime then return appointment booking full today
    addAppointmentRecord(email,timezone,transactWrite,storeId,storeName,storeAddress,storeLogo,name,email,phoneNo,priority,timestamp,expected_appointment_time,avg_wait_time,SKPrefix,context,callback);
}

function addAppointmentRecord(email,timezone,transactWrite,storeId,storeName,storeAddress,storeLogo,name,email,phoneNo,priority,timestamp,expected_appointment_time,avg_wait_time,SKPrefix,context,callback) {
    const appointmentId = uuid.v4();
    transactWrite.push({
        Put: {
            TableName: 'Crowdless',
            Item: {
                PK: storeId,
                SK: `${SKPrefix}#${Number(priority)+1}`,
                Timestamp: timestamp,
                EstimatedAppointmentTime: expected_appointment_time,
                Name: name,
                Email: email,
                PhoneNo: phoneNo,
                Status: 'Waiting',
                AppointmentID: appointmentId,
            }
        }
    });
    docClient.transactWrite({
        TransactItems: transactWrite
    },function(err,data) {
        if(err){
            callback(null,{
                statusCode: 500,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                },
                body: JSON.stringify({
                    Message: "Failed to Write Appointment in DB",
                    error: err
                }),
            });
            context.done(null,err);
            return;
        }
        console.log(data);
        qrcode.toDataURL(appointmentId, function (err, url) {
            if(err){
                console.log('error generating qrcode');
            }
            else {
                var regex = /^data:.+\/(.+);base64,(.*)$/;
                var matches = url.match(regex);
                var data = matches[2];
                var params = {
                    Body: Buffer.from(data,'base64'), 
                    Bucket: "bookings-qr-code", 
                    Key: `${appointmentId}.png`,
                    ACL: "public-read"
                };
                console.log('now uploading');
                 s3.putObject(params, function(err, data) {
                   if (err) {
                       console.log(err); // an error occurred
                   }
                   else {
                       console.log(data);
                       const qrurl = `https://bookings-qr-code.s3.ap-south-1.amazonaws.com/${appointmentId}.png`;
                       console.log(qrurl)
                      let d = `${new Date((expected_appointment_time+timezone.UTCAdjustment) * 1000)}`;
                        var time = d.substr(16,5) + ' ' + timezone.name;
                        var date = d.substr(0,15);
                        var msgType = 1;
                        // const mail = {
                        //     subject: `Your booking details with ${storeName}`,
                        //     html: `<!DOCTYPE html>
                        //             <html lang="en">
                        //             <head>
                        //                 <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
                        //                 <style>
                        //                     button {
                        //                       border: none;
                        //                       background: linear-gradient(180deg, #9748FC 0%, #E96070 100%);
                        //                       border-radius: 5px;
                        //                       padding: 5px;
                        //                       color: white;
                        //                     }
                        //                 </style>
                        //             </head>
                        //             <body> 
                        //                 Hi ${name},
                        //                 <p>Your appointment with ${storeName} is successful</p>
                        //                 <h3>Show this QR Code at the store</h3>
                        //                 <img src="${url}" alt="qr-code">
                        //                 <p>Appointment Time :- ${time} </p>
                        //                 <p>Appointment Date :- ${date}</p>
                        //                 <p style="color:red">PLEASE REACH THE STORE ON TIME TO AVOID CANCELLATION OF YOUR APPOINTMENT</p>
                        //                 <p>For queries or help contact,<br> +91 xxxxxxxxxx or <br> contact@crowdless.tech</p>
                        //                 <p>You can rate your experience with us here <button>RATE US</button></p>
                        //                 <p>Thanks,<br>Team CrowdLess</p>
                        //             </body>
                        //             </html>`
                        // };
                        const sendEmail = {
                            FunctionName: 'sendEmail',
                            InvokeArgs: JSON.stringify({
                                email,
                                msgType,
                                phoneno: phoneNo,
                                details: {
                                    storeName,
                                    storeAddress,
                                    storeLogoUrl: storeLogo,
                                    name,
                                    qrUrl: qrurl,
                                    time,
                                    date,
                                }
                            })
                        };
                        lambda.invokeAsync(sendEmail,function(err,data) {
                            if(err) console.log(err);
                        });
                        // var scheduledMail = {
                        //     subject: `Remainder for you booking with ${storeName}`,
                        //     // html: `<!DOCTYPE html><html lang='en'><head> <meta http-equiv='Content-Type' content='text/html; charset=utf-8'> <style>button {border: none;background: linear-gradient(180deg, #9748FC 0%, #E96070 100%);border-radius: 5px;padding: 5px;color: white;} </style> </head><body>  Hi ${name}, <p>Your appointment with ${storeName} is due at ${time} on ${date}.</p><p style='color:red'>PLEASE REACH THE STORE ON TIME TO AVOID CANCELLATION OF YOUR APPOINTMENT</p><p>For queries or help contact,<br> +91 xxxxxxxxxx or <br> contact@crowdless.tech</p><p>You can rate your experience with us here <button>RATE US</button></p><p>Thanks,<br>Team CrowdLess</p> </body> </html>`,
                        //     html: `<html><body>Hi ${name}, <p>Your appointment with ${storeName} is due at ${time} on ${date}.</p><p style='color:red'>PLEASE REACH THE STORE ON TIME TO AVOID CANCELLATION OF YOUR APPOINTMENT</p><p>For queries or help contact,<br> +91 xxxxxxxxxx or <br> contact@crowdless.tech</p><p>You can rate your experience with us here <button>RATE US</button></p><p>Thanks,<br>Team CrowdLess</p> </body></html>`,
                        // };
                        msgType = 2
                        // console.log(scheduledMail.html)
                        // scheduledMail.html = scheduledMail.html.replace('\n','');
                        // console.log(scheduledMail.html)
                        const scheduleEmail = {
                            FunctionName: 'scheduleEmailTrigger',
                            InvokeArgs: JSON.stringify({
                                email,
                                msgType,
                                phone: phoneNo,
                                details: {
                                    storeName,
                                    storeAddress,
                                    storeLogoUrl: storeLogo,
                                    name,
                                    qrUrl: qrurl,
                                    time,
                                    date,
                                },
                                appointmentId,
                                scheduledTime: expected_appointment_time - 1.5*(avg_wait_time),
                                
                            })
                        }
                        lambda.invokeAsync(scheduleEmail,function(err,data) {
                            if(err) console.log(err);
                        });
                   }
                });
            }
        })
        callback(null,{
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*',
            },
            body: JSON.stringify({
                appointmentId,
            }),
        });
        context.done(null,data);
    })
}

