const AWS = require('aws-sdk');
const pinpoint = new AWS.Pinpoint();
const docClient = new AWS.DynamoDB.DocumentClient();
const mailTemplate = require('./emailTemplate');
const smsTemplate = require('./smsTemplate');

exports.handler = (event,context,callback) => {
    console.log(event);
    var mail,sms;
    if(event.Records) {
        console.log(event.Records[0].Sns.Message);
        const data = JSON.parse(event.Records[0].Sns.Message);
        var {email,msgType,phoneno,details} = data;
    }
    else
        var {email,msgType,phoneno,details} = event;
    
    
    // const {email,mail,phoneno,sms} = {
    //     email: 'sayanbis83@gmail.com',
    //     mail: {
    //         subject: 'Your booking details with Star Stores',
    //         // body:  `Hi Sayantan, your booking details for StarStore are provided below. 
    //         //         TIME:- N/A
    //         //         DATE:- N/A,
    //         //         STATUS:- N/A`,
    //         html: `<html>
    //                 <head></head>
    //                 <body>
    //                   <h1>SHOW THIS QR CODE AT STORE</h1>
    //                   <p><img src="" alt="qrcode"></img></p>
    //                   <p>TIME:- <span id="time"></span></p>
    //                 </body>
    //                 </html>`
    //     },
    //     phoneno: '+917602766742',
    //     sms: `Your appointment with StarStore is scheduled at 12:05 21 Jun 2020 GMT+530.
    //             For QR Code check mail or visit the following link https://beta.crowdless.com/appointment/68rQa5kHugKpXF1EP31LTy `,
    // };
    
    var params = {
        TableName: 'BlockEmails',
        Key: {
            emailId: email,
        }
    }
    docClient.get(params,function(err,data){
        if(err){
            console.log(err);
            //error here
            // return;
        }
        else{
            console.log(data);
            if(data.Item){
                params = {
                    TableName: 'BlockEmails',
                    Key: {
                        emailId: email,
                    },
                    UpdateExpression: 'set noOfAttempts = noOfAttempts + :unity',
                    ExpressionAttributeValues: {
                        ':unity': 1,
                    }
                }
                docClient.update(params,function(err,data){
                    if(err){
                        console.log(err)
                    }
                });
                console.log("Attempted to send mail to blackedlisted mail");
                return;
            }
            else{
                if(msgType === 1){
                    mail = mailTemplate.firstMail(details);
                    sms = smsTemplate.firstSMS(details);
                }
                else if(msgType === 2){
                    mail = mailTemplate.remainderMail(details);
                    sms = smsTemplate.remainderSMS(details);
                }
                sendMail(email,mail,phoneno,sms,context);
            }
        }
    });
};

function sendMail(email,mail,phoneno,sms,context){
    const sender = "Crowdless <no-reply@crowdless.tech>";
    const appId = 'b5e7e4217d5d43b3a871c065cca3ba80';
    var subject = mail.subject;
    var body_html = mail.html;
    var charset = 'UTF-8';
    phoneno = '+91' + phoneno;
    var params = {
        ApplicationId: appId,
        MessageRequest: {
            Addresses: {
                [phoneno]: {
                    ChannelType: "SMS",
                },
                [email] : {
                    ChannelType: 'EMAIL'
                }
            },
            MessageConfiguration: {
                EmailMessage: {
                    FromAddress: sender,
                    SimpleEmail: {
                        Subject: {
                            Charset: charset,
                            Data: subject
                        },
                        HtmlPart: {
                            Charset: charset,
                            Data: body_html
                        },
                    }
                },
                SMSMessage: {
                    Body: sms,
                    MessageType: "TRANSACTIONAL",
                    // SenderId: "AWS",
                }
            }
        }
    };
    pinpoint.sendMessages(params, function(err,data){
        if(err) {
            //CRITICAL ERROR ALERT
            console.log(err.message)
            context.done(err)
        }
        else {
            console.log("Email Send",data);
            context.done(null,data)
        }
    })
}
