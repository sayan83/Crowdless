function firstMail(details) {
    const {storeLogoUrl,storeName,storeAddress,name,qrUrl,time,date} = details;
    const mail = {
        subject: `Your appointment details with ${storeName}`,
        html: `<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
                        <style>
                            #mail-wrapper {
                                padding: 0 20%;
                            }
                            #store-heading-container{
                                text-align: center;
                                margin-bottom: 20px;
                            }
                            #logo-image{
                                height: 50px;
                            }
                            #logo-heading{
                                font-size: 22px;
                                font-weight: 800;
                            }
                            @media only screen and (max-width: 550px){
                                #mail-wrapper{
                                    padding:0;
                                }
                            }
                        </style>
                    </head>
                    <body> 
                        <div id="mail-wrapper">
                            <div id="store-heading-container">
                                <img id="logo-image" src="${storeLogoUrl}" alt="store-logo">
                                <div id="logo-heading">${storeName}</div>
                                <div id="address">
                                    ${storeAddress}
                                </div>
                            </div>
                            <hr>
                            Hi ${name},
                            <p>Your appointment with ${storeName} is successfully booked</p>
                            <h3>Show this QR Code at the store</h3>
                            <img src="${qrUrl}" alt="qr-code">
                            <p>Appointment Time :- ${time} </p>
                            <p>Appointment Date :- ${date}</p>
                            <p style="color:red">PLEASE REACH THE STORE ON TIME TO AVOID CANCELLATION OF YOUR APPOINTMENT</p>
                            <p>For any queries or help contact,<br> +91 xxxxxxxxxx or <br> contact@crowdless.tech</p>
                            <p><a href="#">You can rate your experience with us here</a></p>
                            <p>Thanks,<br>Team CrowdLess</p>
                        </div>
                    </body>
                    </html>`
    }
    return mail;
}
function remainderMail(details) {
    const {storeLogoUrl,storeName,storeAddress,name,qrUrl,time,date} = details;
    const mail = {
        subject: `Remainder for your appointment with ${storeName}`,
        html: `<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
                        <style>
                            #mail-wrapper {
                                padding: 0 20%;
                            }
                            #store-heading-container{
                                text-align: center;
                                margin-bottom: 20px;
                            }
                            #logo-image{
                                height: 50px;
                            }
                            #logo-heading{
                                font-size: 22px;
                                font-weight: 800;
                            }
                            @media only screen and (max-width: 550px){
                                #mail-wrapper{
                                    padding:0;
                                }
                            }
                        </style>
                    </head>
                    <body> 
                        <div id="mail-wrapper">
                            <div id="store-heading-container">
                                <img id="logo-image" src="${storeLogoUrl}" alt="store-logo">
                                <div id="logo-heading">${storeName}</div>
                                <div id="address">
                                    ${storeAddress}
                                </div>
                            </div>
                            <hr>
                            Hi ${name},
                            <p>Your appointment with ${storeName} is due at ${time} on ${date}</p>
                            <p style="color:red">PLEASE REACH THE STORE ON TIME TO AVOID CANCELLATION OF YOUR APPOINTMENT</p>
                            <p>For any queries or help contact,<br> +91 xxxxxxxxxx or <br> contact@crowdless.tech</p>
                            <p><a href="#">You can rate your experience with us here</a></p>
                            <p>Thanks,<br>Team CrowdLess</p>
                        </div>
                    </body>
                    </html>`
    }
    return mail;
}
module.exports = {
    firstMail,
    remainderMail
}