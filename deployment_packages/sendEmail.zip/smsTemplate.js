function firstSMS(details) {
    const {storeLogoUrl,storeName,storeAddress,name,qrUrl,time,date} = details;
    const sms = `Hi, ${name} your appointment with ${storeName} is booked at ${time} on ${date}. Please reach store on time to avoid cancellation.`
    return sms;
}
function remainderSMS(details) {
    const {storeLogoUrl,storeName,storeAddress,name,qrUrl,time,date} = details;
    const sms = `Remainder : Your appointment with ${storeName} is due at ${time} on ${date}. Please reach store on time to avoid cancellation.`;
    return sms;
}
module.exports = {
    firstSMS,
    remainderSMS
}