const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();

exports.handler = (event,context,callback) => {
    console.log(event);
    // const body = JSON.parse(event.body);
    const body = event;
    const storeId = body.storeId;
    const currentPrioritySK = body.currentPrioritySK;
    const lastActivePrioritySK = body.lastActivePrioritySK;
    var params = {
        TableName: 'Crowdless',
        KeyConditionExpression: "PK = :pk and SK between :first and :last",
        ExpressionAttributeValues: {
            ":pk": storeId,
            ":first": lastActivePrioritySK,
            ":last": currentPrioritySK
        }
    };
    docClient.query(params,async function(err,data) {
        if(err) {
            callback(null,{
                statusCode: 500,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                },
                body: JSON.stringify({
                    Message: "Failed to get Appointment Details",
                    error: err
                }),
            });
            context.done(null,err);
            return;
        }
        let transactWrite = [];
        await data.Items.map((item) => {
            transactWrite.push({
                Update: {
                    TableName: "Crowdless",
                    Key: {
                        PK: storeId,
                        SK: item.SK
                    },
                    UpdateExpression: 'set #s = :cancel',
                    ExpressionAttributeNames: {
                        "#s": "Status"
                    },
                    ExpressionAttributeValues: {
                        ":cancel": "Cancelled"
                    }
                }
            });
        });
        console.log(transactWrite);
        docClient.transactWrite({
            TransactItems: transactWrite
        }, function(err,data) {
            if(err) {
                callback(null,{
                    statusCode: 500,
                    headers: {
                        'Access-Control-Allow-Origin': '*',
                    },
                    body: JSON.stringify({
                        Message: "Failed to Cancel Appointments",
                        error: err
                    }),
                });
                context.done(null,err);
                return;
            }
            context.done(null,data)
        });
    });
};
