const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();
const lambda = new AWS.Lambda();

exports.handler = (event,context,callback) => {
    console.log(event);
    // const body = JSON.parse(event.body);
    const body = event;
    const {storeId, appointmentId} = body;
    var params = {
        TableName: "Crowdless",
        IndexName: "AppointmentID-index",
        KeyConditionExpression: "AppointmentID = :apID",
        ExpressionAttributeValues: {
            ":apID": appointmentId
        }
    };
    docClient.query(params, function(err,data) {
        if(err) {
            callback(null,{
                statusCode: 500,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                },
                body: JSON.stringify({
                    Message: "Failed to get Store Details",
                    error: err
                }),
            });
            context.done(null,err);
            return;
        }
        console.log(data);
        const currentTime = Math.ceil((new Date().getTime())/1000);
        if(data.Items[0].EstimatedAppointmentTime - currentTime > 600) {
            var params = {
                FunctionName: 'updateAppointmentTime',
                InvokeArgs: JSON.stringify({
                    storeId: storeId,
                    lastActivePrioritySK: data.Items[0].SK,
                    customerDelay: '-1SET'
                })
            };
            lambda.invokeAsync(params,function(err,data) {
                if(err) console.log(err);
            });
            console.log('Calledd function');
        }
        params = {
            TableName: 'Crowdless',
            Key:{
                "PK": storeId,
                "SK": data.Items[0].SK
            },
            UpdateExpression: "set #s = :cancel",
            ExpressionAttributeValues:{
                ":cancel": "Cancelled",
            },
            ExpressionAttributeNames: {
                "#s": "Status"
            },
            ReturnValues:"UPDATED_NEW"
        };
        docClient.update(params, function(err,data) {
            if(err) {
                callback(null,{
                    statusCode: 500,
                    headers: {
                        'Access-Control-Allow-Origin': '*',
                    },
                    body: JSON.stringify({
                        Message: "Failed to cancel appointment",
                        error: err
                    }),
                });
                context.done(null,err);
                return;
            }
            console.log(data);
            callback(null,{
                statusCode: 200,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                },
                body: JSON.stringify({
                    Message: "Cancelled Successfully",
                    data,
                }),
            });
            context.done(null,err);
            return;
        });
    });
};
