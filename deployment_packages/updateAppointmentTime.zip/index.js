const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();

exports.handler = (event,context,callback) => {
    console.log(event)
    // const body = JSON.parse(event);
    const body = event;
    const storeId = body.storeId;
    const lastActivePrioritySK = body.lastActivePrioritySK;
    let customerDelay = body.customerDelay;
    // const timestamp = (new Date().getTime())/1000;
    const timestamp = 1588770346;
    var params = {
        TableName: 'Crowdless',
        KeyConditionExpression: 'PK = :pk and SK > :lastpriority',
        ExpressionAttributeValues: {
            ":pk": storeId,
            ":lastpriority": lastActivePrioritySK
        },
        ScanIndexForward: false
    };
    if(customerDelay !== '-1SET') {
        params.FilterExpression = 'EstimatedAppointmentTime > :curr_time';
        params.ExpressionAttributeValues[":curr_time"] = timestamp+300;
        params.ScanIndexForward = true;
    }
    docClient.query(params,async function(err,data) {
        if(err) {
            callback(null,{
                statusCode: 500,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                },
                body: JSON.stringify({
                    Message: "Failed to get Appointment Details",
                    error: err
                }),
            });
            context.done(null,err);
            return;
        }
        console.log(data)
        if(customerDelay === '-1SET') {
            const Offline_Consideration_Factor = 2;
            customerDelay = data.Items[0].Avg_Wait_Time * (Offline_Consideration_Factor + 1);
            customerDelay = -customerDelay;
        }
        let transactWrite = [];
        await data.Items.map((item) => {
            transactWrite.push({
                Update: {
                    TableName: "Crowdless",
                    Key: {
                        PK: storeId,
                        SK: item.SK
                    },
                    UpdateExpression: 'set EstimatedAppointmentTime = EstimatedAppointmentTime + :val',
                    ExpressionAttributeValues: {
                        ":val": customerDelay
                    }
                }
            });
        });
        console.log(customerDelay);
        docClient.transactWrite({
            TransactItems: transactWrite
        }, function(err,data) {
            if(err) {
                callback(null,{
                    statusCode: 500,
                    headers: {
                        'Access-Control-Allow-Origin': '*',
                    },
                    body: JSON.stringify({
                        Message: "Failed to Update Appointments",
                        error: err
                    }),
                });
                context.done(null,err);
                return;
            }
            context.done(null,data);
        });
    });
};
