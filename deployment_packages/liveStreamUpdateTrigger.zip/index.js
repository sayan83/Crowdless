const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();
const apiGatewayManagementApi = new AWS.ApiGatewayManagementApi({
    endpoint: ' https://nx7h0fxsdb.execute-api.ap-south-1.amazonaws.com/dev'
});

exports.handler = (event,context,callback) => {
    // TODO implement
    console.log(event.Records[0].dynamodb.NewImage);
    var newCount = event.Records[0].dynamodb.NewImage.Count.L[event.Records[0].dynamodb.NewImage.Count.L.length-1]
    if(!newCount){
        return;
    }
    console.log(newCount,event.Records[0].dynamodb.NewImage.Count.L.length);
    var params = {
        TableName: 'webClientsConnectionIDs'
    }
    docClient.scan(params, onScan);
    
    function onScan(err, data) {
        if (err) {
            //Log and alert for this error
            console.log(err);
            return;
        } 
        else {
            console.log("Scan succeeded.");
            data.Items.forEach(function(item) {
              updateCount(item.ConnectionId,newCount);
            });
    
            // continue scanning if we have more connections, because
            // scan can retrieve a maximum of 1MB of data
            if (typeof data.LastEvaluatedKey != "undefined") {
                console.log("Scanning for more...");
                params.ExclusiveStartKey = data.LastEvaluatedKey;
                docClient.scan(params, onScan);
            }
        }   
    }  
};
function updateCount(connectionId,newCount) {
    const params = {
        ConnectionId: connectionId,
        Data: JSON.stringify({
            'status': 'GRAPH_UPDATED',
            'count': newCount.M.in.N - newCount.M.out.N,
            'timestamp': newCount.M.countTime.N
        })
    };
    apiGatewayManagementApi.postToConnection(params, function (err, data) {
        if (err) {
            console.log(err, err.stack); // an error occurred
        } else {
            console.log(data);           // successful response
        }
    });
}
