exports.handler = (event,context,callback) => {
    // TODO implement
    console.log('event',event);
    console.log('default hit. Do all loggings like date time status event etc');
    callback(null,{
                statusCode: 200,
                headers: {
                    'Access-Control-Allow-Origin': "*",
                },
                body: JSON.stringify({
                    status: 'DEFAULTED'
                }),
            });
};