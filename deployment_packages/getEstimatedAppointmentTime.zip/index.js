const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();

exports.handler = (event,context,callback) => {
    console.log('event here ...',event);
    const date = new Date();
    const currentHrs = `${date.getHours()}${date.getMinutes()<10?date.getMinutes()*10:date.getMinutes()}`;
    const year = `${date.getFullYear()}`;
    const month = (date.getMonth() <= 8)?`0${date.getMonth()+1}`:`${date.getMonth()+1}`;
    const day = (date.getDate() <= 9)?`0${date.getDate()}`:`${date.getDate()}`;
    const SKPrefix = `${year}${month}${day}`
    // const email = event.requestContext.authorizer.claims.email;
    // console.log(email);
    const {storeId} = JSON.parse(event.body)
    // const storeId = 'S001';
    // const userId = 'U005';
    // const email = 'sayanbis83@gmail.com';
    //TODO : get details of store( avg_wait_time & last priority no. )
    var params = {
        TableName: 'Crowdless',
        KeyConditionExpression: "PK = :pk and SK between :date and :info",
        ExpressionAttributeValues: {
            ":pk": storeId,         // Add storeId here
            ":date": SKPrefix,    // Add current date here YYYYMMDD
            ":info": "STORE_INFO"
        },
        ScanIndexForward: false,
        Limit: 4
    };
    docClient.query(params, function(err,data) {
        if(err){
            callback(null,{
                statusCode: 500,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                },
                body: JSON.stringify({
                    Message: "Failed to get store Details",
                    error: err
                }),
            });
            context.done(null,err);
            return;
        }
        console.log(data);
        const avg_wait_time = data.Items[0].Avg_Wait_Time;
        let {bookingEndTime, bookingStartTime} = data.Items[0];
        var last_active_priority_no = data.Items[1].Priority;
        let priority,lastAppointmentTime=0;
        if(data.Items[3]) {
            priority = data.Items[3].SK.substr(data.Items[3].SK.indexOf('#')+1);
            lastAppointmentTime = data.Items[3].EstimatedAppointmentTime;
        }
        else {
            priority = -1;
            if(last_active_priority_no !== -1) {
                last_active_priority_no = -1;
            }
        }
        console.log(avg_wait_time,last_active_priority_no,priority);
        const offline_consideration_factor = 2;
        const date = new Date()
        const timestamp = Math.ceil(date.getTime()/1000);
        const priority_diff = priority - last_active_priority_no;
        let expected_appointment_time;
        if(lastAppointmentTime > timestamp) {
            expected_appointment_time = lastAppointmentTime + (offline_consideration_factor + 1)*avg_wait_time;
        }
        else {
            //if timestamp < appointmentTime then
            if(currentHrs < bookingStartTime) {
                var dateToParse = date.toString();
                bookingStartTime = bookingStartTime.toString()
                var startTime = `${bookingStartTime[0]}${bookingStartTime[1]}:${bookingStartTime[2]}${bookingStartTime[3]}:00`;
                dateToParse = dateToParse.replace(dateToParse.substr(16,8),startTime);
                var newTimestamp = Date.parse(dateToParse)/1000; 
                expected_appointment_time = newTimestamp + (offline_consideration_factor + 1)*avg_wait_time;
            }
            else {
                expected_appointment_time = timestamp + (offline_consideration_factor + 1)*avg_wait_time;
            }
        }
        var dateToParse = date.toString();
        bookingEndTime = bookingEndTime.toString()
        var endTime = `${bookingEndTime[0]}${bookingEndTime[1]}:${bookingEndTime[2]}${bookingEndTime[3]}:00`;
        dateToParse = dateToParse.replace(dateToParse.substr(16,8),endTime);
        console.log(endTime,dateToParse)
        var endTimestamp = Date.parse(dateToParse)/1000;
        console.log(expected_appointment_time,endTimestamp,newTimestamp)
        console.log(currentHrs,expected_appointment_time,endTimestamp,newTimestamp);
        if(expected_appointment_time > endTimestamp){
            callback(null,{
                statusCode: 200,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                },
                body: JSON.stringify({
                    message: 'Appointment Full for today',
                }),
            });
            return;
        }
        // const expected_appointment_time =timestamp + (priority_diff + 1)*avg_wait_time + priority_diff*offline_consideration_factor*avg_wait_time;
        callback(null,{
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*',
            },
            body: JSON.stringify({
                time: expected_appointment_time
            }),
        });
        context.done(null,data);
    });
};