const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();

exports.handler = (event,context,callback) => {
    // TODO implement
    console.log('event',event);
    // const {total_entry, total_exit, count_time,storeId} = event;
    const {total_entry, total_exit, count_time,storeId} = JSON.parse(event.body)
    console.log('data received. Do all loggings like date time status etc');
    let d = new Date(count_time);
    var params = {
        TableName: 'CrowdlessRealTimeFootData',
        Key: {
            "PK": storeId,
            "SK": `${d.getFullYear()}` + ((d.getMonth()+1)>9?`${d.getMonth()+1}`:`0${d.getMonth()+1}`) + `${d.getDate()}`,
        },
        UpdateExpression: 'set #countvalue = list_append(#countvalue, :c)',
        ExpressionAttributeNames: {
            "#countvalue": "Count"
        },
        ExpressionAttributeValues: {
            ":c": [{
                "in": total_entry,
                "out": total_exit,
                "countTime": count_time
            }]
        }
    }
    console.log(params);
    docClient.update(params, function(err,data) {
        if(err) {
            console.log('Error writing data',err);
            return ;
        }
        callback(null,{
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': "*",
            },
            body: JSON.stringify({
                status: 'RECEIVED SUCCESS',
                value: {
                    "TotalEntry": total_entry,
                    "TotalExit": total_exit,
                    "countTime": count_time
                }
            })
        });
    });
};
