const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();

exports.handler = (event,context,callback) => {
    // TODO implement
    console.log(event.Records[0].Sns.Message);
    const Message = JSON.parse(event.Records[0].Sns.Message)
    if(Message.bounce.bounceType === "Permanent") {
        var params = {
            TableName:'BlockEmails',
            Item: {
                emailId: Message.bounce.bouncedRecipients[0].emailAddress,
                noOfAttempts: 1,
                type: 'permanent-bounce'
            }
        }
        console.log(params);
        docClient.put(params,function(err,data){
            if(err){
                console.log(err);
                //alert here
            }
            else {
                console.log(data);
            }
        })
    }
    if(Message.bounce.bounceType === "Transient") {
        var params = {
            TableName:'reviewEmails',
            Item: {
                emailId: Message.bounce.bouncedRecipients[0].emailAddress,
                noOfAttempts: 1,
                details: Message,
            }
        }
        console.log(params);
         docClient.put(params,function(err,data){
            if(err){
                console.log(err);
                //alert here
            }
            else {
                console.log(data);
            }
        })
        //Send an alert for review here
    }
};
