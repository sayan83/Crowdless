const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();
const lambda = new AWS.Lambda()

function checkPriority(statusData,context,callback){
    var {lastPriority, currentPriority, appointmentTime,customerDelayTime,allDelayCount,currentTime,avgWaitTime} = statusData;
    console.log(statusData);
    if(lastPriority == (currentPriority-1)) {
        // TODO : continue according to docs (DONE)
        statusData.condition = 1;
        console.log('1')
        checkTime(statusData,context,callback);
    }
    else if(lastPriority < (currentPriority-1)){
        // TODO : continue according to 'USER IS AHEAD BY MORE THAN 1 PRIORITY_NO FROM LAST_ACTIVE_PRIORITY_NO' section from docs (DONE)
        statusData.condition = 2;
        checkTime(statusData,context,callback);
    }
    else {
        // TODO : continue according to 'USERS PRIORITY_NO IS LESS THAN LAST_ACTIVE_PRIORITY_NO' section from docs (DONE)
        statusData.condition = 3;
        checkTime(statusData,context,callback);
    }
    console.log(statusData.condition,currentPriority-1 , lastPriority);
}

function checkTime(statusData,context,callback) {
    // TODO : If no of missing people are not simultaneously 3 then their appointment are not automatically cancelled.
    // Example : if 1 is missing and 2,3,4,5 are on time and DONE then 1 is not cancelled.
    
    //TODO : Check with decimal priority number because of moretime request
    var transactWrite = [
        {
            Update: {
                TableName: 'Crowdless',
                Key: { 
                    PK: statusData.storeId,
                    // AppointmentID: statusData.appointmentId,
                    SK: statusData.SK,
                },
                UpdateExpression: 'set #s = :done',
                ExpressionAttributeNames: {
                    "#s": "Status"
                },
                ExpressionAttributeValues: {
                    ':done': "Done",
                }
            }
        },    
    ];
    var {lastPriority, currentPriority,appointmentTime,customerDelayTime,allDelayCount,currentTime,avgWaitTime,condition} = statusData;
    const priorityDiff = currentPriority - lastPriority;
    if(condition === 3) {
        //TODO : user is late, accepted and processed according to condition in docs (DONE)
        customerDelayTime += avgWaitTime;
        if (customerDelayTime < 300) {
            transactWrite.push({
                Update: {
                    TableName: "Crowdless",
                    Key: {
                        PK: statusData.storeId,
                        SK: "DELAY_COUNT"
                    },
                    UpdateExpression: 'set Customer_Delay_Time = :time',
                    ExpressionAttributeValues: {
                        ":time": customerDelayTime
                    }
                }
            });
        }
        else {
            transactWrite.push({
                Update: {
                    TableName: "Crowdless",
                    Key: {
                        PK: statusData.storeId,
                        SK: "DELAY_COUNT"
                    },
                    UpdateExpression: 'set Customer_Delay_Time = :time',
                    ExpressionAttributeValues: {
                        ":time": 0
                    }
                }
            });
            // TODO : call lambda function to update appointment time of next users (DONE)
            var params = {
                FunctionName: 'updateAppointmentTime',
                InvokeArgs: JSON.stringify({
                    storeId: statusData.storeId,
                    lastActivePrioritySK: statusData.SK.substr(0,8)+'#'+lastPriority,
                    customerDelay: customerDelayTime
                })
            }
            lambda.invokeAsync(params,function(err,data) {
                if(err) console.log(err);
            });
            console.log('Calledd function');
        }
    }
    else if(currentTime > (appointmentTime-avgWaitTime) && currentTime < (appointmentTime+avgWaitTime)) {
        // User is on time
        if(allDelayCount !== 0) {
            // TODO : store is on time Reset DELAY_COUNT to 0 (DONE)
            transactWrite.push({
                Update: {
                    TableName: "Crowdless",
                    Key: {
                        PK: statusData.storeId,
                        SK: "DELAY_COUNT"
                    },
                    UpdateExpression: 'set #val = :count',
                    ExpressionAttributeNames: {
                        "#val": "Value"
                    },
                    ExpressionAttributeValues: {
                        ":count": 0
                    }
                }
            });
        }
        if(condition === 2) {
            if(priorityDiff > 3) {
                // TODO : call lambda functions to cancel appointments of given users.(DONE)
                var params = {
                    FunctionName: 'cancelAppointments',
                    InvokeArgs: JSON.stringify({
                        storeId: statusData.storeId,
                        lastActivePrioritySK: statusData.SK.substr(0,8)+'#'+(lastPriority+1),
                        currentPrioritySK: statusData.SK.substr(0,8)+'#'+(currentPriority-3)
                    })
                };
                lambda.invokeAsync(params,function(err,data) {
                    if(err) console.log(err);
                });
                console.log('Called cancel function for ontime');
            }
        }
        // TODO:  Push write instructions to transactWrite update LAST_ACTIVE_PRIORITY_NO (DONE)
        transactWrite.push({
            Update: {
                TableName: "Crowdless",
                Key: {
                    PK: statusData.storeId,
                    SK: "LAST_ACTIVE_PRIORITY_NO"
                },
                UpdateExpression: 'set Priority = :val',
                ExpressionAttributeValues: {
                    ":val": currentPriority
                }
            }
        });
    }
    else if(currentTime > (appointmentTime+avgWaitTime)) {
        let offlineConsiderationFactor = 2; //Add data here if needed
        if(currentTime > (appointmentTime+(offlineConsiderationFactor+1)*avgWaitTime)) {
            if(allDelayCount > 4) {
                //  TODO : probable store delay. call lambda function to update appointment time of next users(DONE)
                var params = {
                    FunctionName: 'updateAppointmentTime',
                    InvokeArgs: JSON.stringify({
                        storeId: statusData.storeId,
                        lastActivePrioritySK: statusData.SK.substr(0,8)+'#'+currentPriority,
                        customerDelay: (currentTime - statusData.appointmentTime)
                    })
                };
                lambda.invokeAsync(params,function(err,data) {
                    if(err) console.log(err);
                });
                console.log('Called function');
                // TODO : reset delay count to 0 (DONE)
                transactWrite.push({
                    Update: {
                        TableName: "Crowdless",
                        Key: {
                            PK: statusData.storeId,
                            SK: "DELAY_COUNT"
                        },
                        UpdateExpression: 'set #val = :count',
                        ExpressionAttributeNames: {
                            "#val": "Value"
                        },
                        ExpressionAttributeValues: {
                            ":count": 0
                        }
                    }
                });
            }
            else {
                // TODO : increment delay count by 1 (DONE)
                transactWrite.push({
                    Update: {
                        TableName: "Crowdless",
                        Key: {
                            PK: statusData.storeId,
                            SK: "DELAY_COUNT"
                        },
                        UpdateExpression: 'set #val = :count',
                        ExpressionAttributeNames: {
                            "#val": "Value"
                        },
                        ExpressionAttributeValues: {
                            ":count": (Number(allDelayCount)+1)
                        }
                    }
                });
            }
        }
        if(priorityDiff > 3) {
                // TODO : call lambda functions to cancel appointments of given users.(DONE)
                var params = {
                    FunctionName: 'cancelAppointments',
                    InvokeArgs: JSON.stringify({
                        storeId: statusData.storeId,
                        lastActivePrioritySK: statusData.SK.substr(0,8)+'#'+(lastPriority+1),
                        currentPrioritySK: statusData.SK.substr(0,8)+'#'+(currentPriority-3)
                    })
                };
                lambda.invokeAsync(params,function(err,data) {
                    if(err) console.log(err);
                });
                console.log('Called cancel function for ontime');
        }
        // TODD : Update LAST_ACTIVE_PRIORITY_NO (DONE)
        transactWrite.push({
            Update: {
                TableName: "Crowdless",
                Key: {
                    PK: statusData.storeId,
                    SK: "LAST_ACTIVE_PRIORITY_NO"
                },
                UpdateExpression: 'set Priority = :val',
                ExpressionAttributeValues: {
                    ":val": currentPriority
                }
            }
        });
    }
    else {
        // TODO : user is before time. respond accordingly (DONE)
        transactWrite = [];
        callback(null,{
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*',
            },
            body: JSON.stringify({
                Message: "Before Time"
            }),
        });
        context.done(null,{
                Message: "Before Time"
            });
        return;
    }
    updateDB(transactWrite,context,callback);
}

function updateDB(transactWrite,context,callback) {
    console.log(transactWrite)
    docClient.transactWrite({
        TransactItems: transactWrite
    }, function(err,data) {
        if(err) {
            callback(null,{
                statusCode: 500,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                },
                body: JSON.stringify({
                    Message: "Failed to Write Appointment in DB",
                    error: err
                }),
            });
            context.done(null,err);
            return;
        }
        console.log(data);
        callback(null,{
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*',
            },
            body: JSON.stringify(data),
        });
        context.done(null,data);
    });
}

module.exports = {
    checkPriority,
}