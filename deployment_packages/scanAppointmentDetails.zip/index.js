const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();
const appointmentHandler = require('./handleAppointment');

exports.handler = (event,context,callback) => {
    console.log('event here ...',event);
    const date = new Date();
    const year = `${date.getFullYear()}`;
    const month = (date.getMonth() <= 8)?`0${date.getMonth()+1}`:`${date.getMonth()+1}`;
    const day = (date.getDate() <= 9)?`0${date.getDate()}`:`${date.getDate()}`;
    const SKPrefix = `${year}${month}${day}`;
    // const email = event.requestContext.authorizer.claims.email;
    // console.log(email);
    // const payload = JSON.parse(event.body)
    // const appointmentId = payload.appointmentId;
    // const storeId = payload.storeId;
    const appointmentId = 'b11b6ab7-044f-4c4a-8dc9-6f353bf8b510';
    const storeId = 'S001';
    var params = {
        TableName: 'Crowdless',
        KeyConditionExpression: "PK = :pk and SK between :delay and :info",
        ExpressionAttributeValues: {
            ":pk": storeId,
            ":delay": "DELAY_COUNT",
            ":info": "STORE_INFO"
        }
    };
    docClient.query(params, function(err,data) {
        if(err){
            callback(null,{
                statusCode: 500,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                },
                body: JSON.stringify({
                    Message: "Failed to get Store Details",
                    error: err
                }),
            });
            context.done(null,err);
            return;
        }
        console.log('store data',data);
        getAppointmentDetails(context,callback,date,storeId,appointmentId,data.Items[0].Customer_Delay_Time,data.Items[0].Value,data.Items[1].Priority,data.Items[2].Avg_Wait_Time);
    });
};

function getAppointmentDetails(context,callback,date,storeId,appointmentId,customerDelayTime,allDelayCount,lastPriority,avgWaitTime){
    var params = {
        TableName: "Crowdless",
        IndexName: "AppointmentID-index",
        // Key: {
        //     "AppointmentID": appointmentId,
        // }
        KeyConditionExpression: "AppointmentID = :apID",
        ExpressionAttributeValues: {
            ":apID": appointmentId
        }
    };
    docClient.query(params, function(err,data) {
        if(err){
            callback(null,{
                statusCode: 500,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                },
                body: JSON.stringify({
                    Message: "Failed to get Store Details",
                    error: err
                }),
            });
            context.done(null,err);
            return;
        }
        if(data.Count === 0) {
            callback(null,{
                statusCode: 400,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                },
                body: JSON.stringify({
                    Message: "Invalid Appointment",
                    error: err
                }),
            });
            return ;
        }
        console.log('appointment data',data);
        if(data.Items[0].Status === 'Done') {
            callback(null,{
                statusCode: 200,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                },
                body: JSON.stringify({
                    Message: "Appointment is already done",
                }),
            });
            context.done(null,err);
            return;
        }
        // else if(data.Items[0].Status === 'Cancelled' || (data.Items[0].EstimatedAppointmentTime + 43200) < (date.getTime()/1000)) {
        else if(data.Items[0].Status === 'Cancelled') {
            callback(null,{
                statusCode: 200,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                },
                body: JSON.stringify({
                    Message: "Appointment is cancelled",
                    CancelCause: data.Items[0].cancelCause,
                }),
            });
            context.done(null,err);
            return;
        }
        if(data.Items[0].PK !== storeId) {
            callback(null,{
                statusCode: 200,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                },
                body: JSON.stringify({
                    Message: "Wrong Store",
                }),
            });
            context.done(null,err);
            return;
        }
        const statusData = {
            lastPriority,
            currentPriority: data.Items[0].SK.substr(data.Items[0].SK.indexOf('#')+1),
            appointmentTime: data.Items[0].EstimatedAppointmentTime,
            customerDelayTime,
            allDelayCount,
            currentTime: Math.ceil(date.getTime()/1000),
            avgWaitTime,
            SK: data.Items[0].SK,
            storeId
        }
        appointmentHandler.checkPriority(statusData,context,callback);
    });
}

// TODO : If appointments are scanned next day without cancellation, mark them as cancelled