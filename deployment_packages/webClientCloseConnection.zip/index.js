const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();

exports.handler = (event,context,callback) => {
    // TODO implement
    console.log('event',event);
    console.log('connection opened. Do all loggings like date time status etc');
    var params = {
        TableName: 'webClientsConnectionIDs',
        Key: {
            'ConnectionId': event.requestContext.connectionId,
        }
    }
    docClient.delete(params, function(err,data) {
        if(err){
            console.log(err);
            // ADD LOGS TO INFORM ERROR
        }
        //Return all store details here 
        callback(null,{
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': "*",
            },
            body: JSON.stringify({
                status: 'DISCONNECTED'
            }),
        });
    })
};
