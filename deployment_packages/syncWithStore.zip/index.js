const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();

exports.handler = (event,context,callback) => {
    // TODO implement
    console.log(event);
    // const storeId = 'S0001';
    const storeId = JSON.parse(event.body).storeId;
    let d = new Date();
    var params = {
        TableName: 'CrowdlessRealTimeFootData',
        Key: {
            "PK": storeId,
            "SK":  `${d.getFullYear()}` + ((d.getMonth()+1)>9?`${d.getMonth()+1}`:`0${d.getMonth()+1}`) + `${d.getDate()}`,
        }
    }
    docClient.get(params, function(err,data) {
        if(err) {
            callback(null,{
                statusCode: 400,
                headers: {
                    'Access-Control-Allow-Origin': "*",
                },
                body: JSON.stringify({
                    status: 'Store Data Not Found'
                }),
            });
            return ;
        }
        if(!data.Item) {
            console.log('ddd',data);
            callback(null,{
                statusCode: 400,
                headers: {
                    'Access-Control-Allow-Origin': "*",
                },
                body: JSON.stringify({
                    status: 'Store Data Not Found'
                }),
            });
            return ;
            // ERROR: IF STORE RECORD NOT PRESENT FOR THAT PARTICULAR DAY THEN ERROR IN SAVING CONNECTION TO DB
        }
        console.log('data',data,'count ',data);
        let countData = []
        data.Item.Count.map(data => {
            countData.push([data.countTime,(data.in - data.out)])
        })
        console.log(countData)
        var params = {
            TableName: 'webClientsConnectionIDs',
            Item : {
                'ConnectionId': event.requestContext.connectionId,
                storeId,
            }
        }
        docClient.put(params, function(err,data) {
            if(err){
                callback(null,{
                    statusCode: 500,
                    headers: {
                        'Access-Control-Allow-Origin': "*",
                    },
                    body: JSON.stringify({
                        status: 'UNEXPECTED ERROR, FAILED TO SAVE CONNECTION. PLEASE RETRY',
                        error: err,
                    }),
                });
                return ;
            }
            //Return all store details here 
            callback(null,{
                statusCode: 200,
                headers: {
                    'Access-Control-Allow-Origin': "*",
                },
                body: JSON.stringify({
                    status: 'SYNCED',
                    graphData: countData,
                }),
            });
        })  
    })
};
