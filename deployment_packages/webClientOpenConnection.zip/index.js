const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();

exports.handler = (event,context,callback) => {
    // TODO implement
    console.log('event',event);
    console.log('connection opened. Do all loggings like date time status etc');
    callback(null,{
        statusCode: 200,
        headers: {
            'Access-Control-Allow-Origin': "*",
        },
        body: JSON.stringify({
            status: 'CONNECTED'
        }),
    });
};
