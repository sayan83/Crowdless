const AWS = require('aws-sdk');
const cloudwatchevent = new AWS.CloudWatchEvents()

exports.handler = (event,context,callback) => {
    // TODO implement
    console.log(event);
    const {scheduledTime, email,msgType,details,phone,appointmentId} = event;
    const d = new Date(scheduledTime*1000);
    var cron = `cron(${d.getMinutes()} ${d.getHours()} ${d.getDate()} ${d.getMonth()+1} ? ${d.getFullYear()})`
    var params = {
        Name: `${appointmentId}`,
        ScheduleExpression: cron,
        RoleArn: 'arn:aws:iam::209223835471:role/crowdlessCloudWatchEventInvoke',
    }
    cloudwatchevent.putRule(params, function(err,data) {
        if(err) {
            console.log('putrule err',err);
            //log accordingly
        }
        else {
            console.log(data);
            params = {
                Rule: `${appointmentId}`,
                Targets: [
                    {
                        Arn: 'arn:aws:sns:ap-south-1:209223835471:sendRemainderMail',
                        Id: appointmentId,
                        Input: JSON.stringify({
                            msgType,
                            email,
                            phoneno: phone,
                            details,
                        })
                    },
                ]
            }
            cloudwatchevent.putTargets(params,function(err,data) {
                if(err) {
                    console.log('puttarget error',err);
                    //LOG here
                }
                else {
                    console.log(data);
                    context.done(null,data);
                }
            })
        }
    })
};
