const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();

exports.handler = (event,context,callback) => {
    // TODO implement
    console.log(event);
    // const storeId = 'S002';
    const storeId = JSON.parse(event.body).storeId;
    let d = new Date();
    console.log(`${d.getFullYear()}` + ((d.getMonth()+1)>9?`${d.getMonth()+1}`:`0${d.getMonth()+1}`) + `${d.getDate()}`)
    var params = {
        TableName: 'CrowdlessRealTimeFootData',
        Key: {
            "PK": storeId,
            "SK": `${d.getFullYear()}` + ((d.getMonth()+1)>9?`${d.getMonth()+1}`:`0${d.getMonth()+1}`) + `${d.getDate()}`,
        }
    }
    docClient.get(params, function(err,data) {
        if(err) {
            callback(null,{
                statusCode: 500,
                headers: {
                    'Access-Control-Allow-Origin': "*",
                },
                body: JSON.stringify({
                    status: 'Some error occured in initializing Database',
                }),
            });
        }
        if(!data.Item) {
            console.log('yeee');
            var params = {
                TableName: 'CrowdlessRealTimeFootData',
                Item: {
                    PK: storeId,
                    SK: `${d.getFullYear()}` + ((d.getMonth()+1)>9?`${d.getMonth()+1}`:`0${d.getMonth()+1}`) + `${d.getDate()}`,
                    Count: []
                }
            }
            docClient.put(params, function(err,data) {
                if(err || data === {}){
                    callback(null,{
                        statusCode: 500,
                        headers: {
                            'Access-Control-Allow-Origin': "*",
                        },
                        body: JSON.stringify({
                            status: 'Some error occured in initializing Database',
                        }),
                    });
                    return ;
                }
                callback(null,{
                    statusCode: 200,
                    headers: {
                        'Access-Control-Allow-Origin': "*",
                    },
                    body: JSON.stringify({
                        status: 'Initialization Successful',
                    }),
                });
            })
            return;
        }
        console.log(data)
        callback(null,{
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': "*",
            },
            body: JSON.stringify({
                status: 'Initialized Successful',
            }),
        });
    });
}
