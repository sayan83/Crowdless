const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient()

exports.handler = (event,context,callback) => {
    console.log(event);
    const {appointmentId} = JSON.parse(event.body)
    // const appointmentId = '2c37478d-8955-4b9b-8a3b-066203bacff0';
    var params = {
        TableName: "Crowdless",
        IndexName: "AppointmentID-index",
        KeyConditionExpression: "AppointmentID = :apID",
        ExpressionAttributeValues: {
            ":apID": appointmentId
        }
    };
    docClient.query(params, function(err,data) {
        if(err){
            callback(null,{
                statusCode: 500,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                },
                body: JSON.stringify({
                    Message: "Failed to get Appointment Details",
                    error: err
                }),
            });
            context.done(null,err);
            return;
        }
        if(data.Count === 0) {
            callback(null,{
                statusCode: 400,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                },
                body: JSON.stringify({
                    Message: "Invalid Appointment",
                    error: err
                }),
            });
            return ;
        }
        console.log(data);
        let params = {
            TableName: 'crowdlessRegisteredStoreDetails',
            Key: {
                storeId : data.Items[0].PK
            }
        }
        docClient.get(params,function(err,storeData) {
            if(err){
                //CRITICAL ERROR TRIGGER ALERT
                callback(null,{
                    statusCode: 500,
                    headers: {
                        'Access-Control-Allow-Origin': '*',
                    },
                    body: JSON.stringify({
                        Message: 'Store Data not found',
                        err,
                    }),
                });
                return ;
            }
            if(storeData === {}) {
                //CRITICAL ERROR TRIGGER ALERT
                callback(null,{
                    statusCode: 500,
                    headers: {
                        'Access-Control-Allow-Origin': '*',
                    },
                    body: JSON.stringify({
                        Message: 'Store Data not found'
                    }),
                });
                return ;
            }
            callback(null,{
                statusCode: 200,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                },
                body: JSON.stringify({
                    ...data.Items[0],
                    storeName: storeData.Item.storeName,
                    storeAddress: storeData.Item.storeAddress,
                    storeLogo: storeData.Item.storeLogo,
                }),
            });
        })
        
    })
};
