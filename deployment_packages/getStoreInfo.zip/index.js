const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();

exports.handler = (event,context,callback) => {
    // TODO implement
    console.log(event);
    // const storeId = 'S002'
    const storeId = JSON.parse(event.body).storeId;
    var params = {
        TableName: 'crowdlessRegisteredStoreDetails',
        Key: {
            storeId,
        }
    }
    console.log(storeId)
    docClient.get(params, function(err,data) {
        if(err) {
            console.log(err);
            callback(null,{
                statusCode: 500,
                headers: {
                    'Access-Control-Allow-Origin': "*",
                },
                body: JSON.stringify({
                    status: 'ERROR OCCURED',
                    err,
                }),
            });
            return ;
        }
        console.log(data);
        if(!data.Item){
            callback(null,{
                statusCode: 400,
                headers: {
                    'Access-Control-Allow-Origin': "*",
                },
                body: JSON.stringify({
                    status: 'STORE NOT FOUND'
                }),
            });
            return ;
        }
        callback(null,{
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': "*",
            },
            body: JSON.stringify({
                status: 'SUCCESSFUL',
                data: data.Item,
            }),
        });
    });
};
